var express = require('express');
var router = express.Router();
var router = require('express').Router();
var app = express();
module.exports = router;
var db = require('../db');

/* POST  submitLogin . */
        router.post("/submitLogin",function(request,response){
            var username= request.body.username;
            var password= request.body.password;
            if(username && password ){
            db.query('SELECT * FROM login WHERE username = ? AND password = ?', [username, password], function(err, results) {
        
                if (err){
                    throw err;
                } 
                if (results.length > 0) {
                    request.session.loggedin = true;
                    request.session.username = username;
                    response.redirect("/detailView");
                } else {
                    response.redirect("/roomlist");
                }			
                response.end();
               
              });
        }
        });
        

         /* GET Logout Method  . */
        router.get("/logout",function(req,res){
            req.session.destroy(function(err)
            { if(err)
                { 
                console.log(err); 
                } 
                else 
                { 
                res.redirect('/'); 
                } 
                }); 
               });

    
module.exports = router;   
    
